package modeloBeans;

/**
 *
 * @author Carlos
 */
public class BeansProduto {

    private int codigo_pro;
    private int codigo_barras;
    private String produto;
    private int quantidade;
    private float valor_uni;
    private byte[] imagem_pro;
    private String pesquisa;
    private int retornar;
    
    
    /**
     * @return the pesquisa
     */
    public String getPesquisa() {
        return pesquisa;
    }

    /**
     * @param pesquisa the pesquisa to set
     */
    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }
    

    
    /**
     * @return the codigo_pro
     */
    public int getCodigo_pro() {
        return codigo_pro;
    }

    /**
     * @param codigo_pro the codigo_pro to set
     */
    public void setCodigo_pro(int codigo_pro) {
        this.codigo_pro = codigo_pro;
    }

    /**
     * @return the codigo_barras
     */
    public int getCodigo_barras() {
        return codigo_barras;
    }

    /**
     * @param codigo_barras the codigo_barras to set
     */
    public void setCodigo_barras(int codigo_barras) {
        this.codigo_barras = codigo_barras;
    }

    /**
     * @return the produto
     */
    public String getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(String produto) {
        this.produto = produto;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade the quantidade to set
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * @return the valor_uni
     */
    public float getValor_uni() {
        return valor_uni;
    }

    /**
     * @param valor_uni the valor_uni to set
     */
    public void setValor_uni(float valor_uni) {
        this.valor_uni = valor_uni;
    }

    /**
     * @return the imagem_pro
     */
    public byte[] getImagem_pro() {
        return imagem_pro;
    }

    /**
     * @param imagem_pro the imagem_pro to set
     */
    public void setImagem_pro(byte[] imagem_pro) {
        this.imagem_pro = imagem_pro;
    }

    /**
     * @return the retornar
     */
    public int getRetornar() {
        return retornar;
    }

    /**
     * @param retornar the retornar to set
     */
    public void setRetornar(int retornar) {
        this.retornar = retornar;
    }
    
}