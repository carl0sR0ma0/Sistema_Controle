package modeloConection;

import java.sql.*;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Carlos
 */
public class ConexaoBD {
    
    public Statement stm;
    public ResultSet rs;
    private String driver = "com.mysql.jdbc.Driver";
    private String caminho = "jdbc:mysql://localhost/syscon";
    private String usuario = "root";
    private String senha = "";
    private Connection con;
    
    public void conexao(){
        try {
            System.setProperty("jdbc.Drivers", driver);
            con = DriverManager .getConnection(caminho, usuario, senha);
            //JOptionPane.showMessageDialog(null, "Conexão Efetuada Com Sucesso!!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao se conectar com o banco de dados:\n" + ex.getMessage());
        }
    }
    
    public void executaSQL(String sql){
        try {
            stm = getCon().createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao ExecutaSql:\n" + ex.getMessage());
        }
    }
    
    public void desconecta(){
        try{
            getCon().close();
            //JOptionPane.showMessageDialog(null, "BD desconectado com sucesso!!");
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Erro ao fechar conexao com BD:\n"+ex.getMessage());
        }
    }

    public boolean executarUpdateDeleteSQL(String pSQL) {
        try {
            stm = (getCon().createStatement());

            stm.executeUpdate(pSQL);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * @return the con
     */
    public Connection getCon() {
        return con;
    }

    public int insertSQL(String pSQL) {
        int status = 0;
        try {
            stm = (getCon().createStatement());
            // Definido o Statement, executamos a query no banco de dados
            stm.executeUpdate(pSQL);

            rs = (stm.executeQuery("SELECT last_insert codigo_produto()"));
            
            //recupera o ultimo id inserido
            while(rs.next()){
                status = rs.getInt(1);
            }
            
            //retorna o ultimo id inserido
            return status;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return status;
        }
    }
}