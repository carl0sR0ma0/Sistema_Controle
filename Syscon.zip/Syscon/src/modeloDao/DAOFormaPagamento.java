package modeloDAO;

import model.ModelFormaPagamento;
import modeloConection.ConexaoBD;
import java.util.ArrayList;
/**
*
* @author Carlos
*/
public class DAOFormaPagamento extends ConexaoBD {

    ConexaoBD conex = new ConexaoBD();
    
    /**
    * grava FormaPagamento
    * @param pModelFormaPagamento
    * return int
    */
    public int salvarFormaPagamentoDAO(ModelFormaPagamento pModelFormaPagamento){
        try {
            
            conex.conexao();
            return conex.insertSQL(
                "INSERT INTO forma_pagamento ("
                    + "id,"
                    + "descricao,"
                    + "desconto,"
                    + "parcelas,"
                    + "situacao"
                + ") VALUES ("
                    + "'" + pModelFormaPagamento.getIdForPag() + "',"
                    + "'" + pModelFormaPagamento.getDescricao() + "',"
                    + "'" + pModelFormaPagamento.getDesconto() + "',"
                    + "'" + pModelFormaPagamento.getParcelas() + "',"
                    + "'" + pModelFormaPagamento.getSituacao() + "'"
                + ");"
            );
        }catch(Exception e){
            e.printStackTrace();
            return 0;
        }finally{
            conex.desconecta();
        }
    }

    /**
    * recupera FormaPagamento
    * @param pIdForPag
    * return ModelFormaPagamento
    */
    public ModelFormaPagamento getFormaPagamentoDAO(int pIdForPag){
        ModelFormaPagamento modelFormaPagamento = new ModelFormaPagamento();
        try {
            conex.conexao();
            conex.executaSQL(
                "SELECT "
                    + "id,"
                    + "descricao,"
                    + "desconto,"
                    + "parcelas,"
                    + "situacao"
                 + " FROM"
                     + " forma_pagamento"
                 + " WHERE"
                     + " pk_id_for_pag = '" + pIdForPag + "'"
                + ";"
            );

            while(conex.rs.next()){
                modelFormaPagamento.setIdForPag(conex.rs.getInt(1));
                modelFormaPagamento.setDescricao(conex.rs.getString(2));
                modelFormaPagamento.setDesconto(conex.rs.getFloat(3));
                modelFormaPagamento.setParcelas(conex.rs.getInt(4));
                modelFormaPagamento.setSituacao(conex.rs.getInt(5));
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            conex.desconecta();
        }
        return modelFormaPagamento;
    }

    /**
    * recupera uma lista de FormaPagamento
        * return ArrayList
    */
    public ArrayList<ModelFormaPagamento> getListaFormaPagamentoDAO(){
        ArrayList<ModelFormaPagamento> listamodelFormaPagamento = new ArrayList();
        ModelFormaPagamento modelFormaPagamento = new ModelFormaPagamento();
        try {
            conex.conexao();
            conex.executaSQL(
                "SELECT "
                    + "id,"
                    + "descricao,"
                    + "desconto,"
                    + "parcelas,"
                    + "situacao"
                 + " FROM"
                     + " forma_pagamento"
                + ";"
            );

            while(conex.rs.next()){
                modelFormaPagamento = new ModelFormaPagamento();
                modelFormaPagamento.setIdForPag(conex.rs.getInt(1));
                modelFormaPagamento.setDescricao(conex.rs.getString(2));
                modelFormaPagamento.setDesconto(conex.rs.getFloat(3));
                modelFormaPagamento.setParcelas(conex.rs.getInt(4));
                modelFormaPagamento.setSituacao(conex.rs.getInt(5));
                listamodelFormaPagamento.add(modelFormaPagamento);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            conex.desconecta();
        }
        return listamodelFormaPagamento;
    }

    /**
    * atualiza FormaPagamento
    * @param pModelFormaPagamento
    * return boolean
    */
    public boolean atualizarFormaPagamentoDAO(ModelFormaPagamento pModelFormaPagamento){
        try {
            conex.conexao();
            return conex.executarUpdateDeleteSQL(
                "UPDATE forma_pagamento SET "
                    + "id = '" + pModelFormaPagamento.getIdForPag() + "',"
                    + "descricao = '" + pModelFormaPagamento.getDescricao() + "',"
                    + "desconto = '" + pModelFormaPagamento.getDesconto() + "',"
                    + "parcelas = '" + pModelFormaPagamento.getParcelas() + "',"
                    + "situacao = '" + pModelFormaPagamento.getSituacao() + "'"
                + " WHERE "
                    + "id = '" + pModelFormaPagamento.getIdForPag() + "'"
                + ";"
            );
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }finally{
            conex.desconecta();
        }
    }

    /**
    * exclui FormaPagamento
    * @param pIdForPag
    * return boolean
    */
    public boolean excluirFormaPagamentoDAO(int pIdForPag){
        try {
            conex.conexao();
            return this.executarUpdateDeleteSQL(
                "DELETE FROM forma_pagamento "
                + " WHERE "
                    + "id = '" + pIdForPag + "'"
                + ";"
            );
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }finally{
            conex.desconecta();
        }
    }
}