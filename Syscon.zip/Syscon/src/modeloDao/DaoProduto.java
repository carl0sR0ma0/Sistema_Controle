package modeloDao;

import modeloConection.ConexaoBD;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import modeloBeans.BeansProduto;

/**
 *
 * @author Carlos
 */
public class DaoProduto {
    
    public String ImgPath = null;
    public int pos = 0;
    
    public int result2;
    public JFileChooser file2 = new JFileChooser();
    
    ConexaoBD conex = new ConexaoBD();
    BeansProduto mod = new BeansProduto();
    
    public ImageIcon ResizeImage(String imagePath, byte[] pic){
        
        ImageIcon myImage = null;
        
        if(imagePath != null){
            myImage = new ImageIcon(imagePath);
        }else{
            myImage = new ImageIcon(pic);
        }
        
        Image img = myImage.getImage();
        Image img2 = img.getScaledInstance(227, 167, Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(img2);
        return image;
    }
    
    public void SelecionarImagem(){
        
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.home")));
        
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.images", "jpg", "png");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);
        
        result2 = result;
        file2 = file;
    }
    
    public void Salvar(BeansProduto mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.getCon().prepareStatement("INSERT INTO produtos(codigo_barras,produto,quantidade,valor_uni,imagem_pro) VALUES (?,?,?,?,?)");
            pst.setInt(1, mod.getCodigo_barras());
            pst.setString(2, mod.getProduto());
            pst.setInt(3, mod.getQuantidade());
            pst.setFloat(4, mod.getValor_uni());
            
            InputStream img  = new FileInputStream(new File(ImgPath));
            pst.setBlob(5, img);
            
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Dados Inseridos Com Sucesso!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro Ao Inserir Dados! /nErro:" + ex.getMessage());
        }
        conex.desconecta();
    }
    
    public void Editar(BeansProduto mod){
        conex.conexao();
        
        if(ImgPath == null){
            try {
                PreparedStatement pst = conex.getCon().prepareStatement("UPDATE produtos SET codigo_barras=?, produto=?, quantidade=?, valor_uni=? WHERE codigo_produto=?");
                pst.setInt(1, mod.getCodigo_barras());
                pst.setString(2, mod.getProduto());
                pst.setInt(3, mod.getQuantidade());
                pst.setFloat(4, mod.getValor_uni());
                pst.setInt(5, mod.getCodigo_pro());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Dados Alterados Com Sucesso!!!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro Na Alteração de Dados/n" + ex.getMessage());
            }
        }else{
            try {
                InputStream img = new FileInputStream(new File(ImgPath));
                
                PreparedStatement pst = conex.getCon().prepareStatement("UPDATE produtos SET codigo_barras=?, produto=?, quantidade=?, valor_uni=?, imagem_pro=? WHERE codigo_produto=?");
                pst.setInt(1, mod.getCodigo_barras());
                pst.setString(2, mod.getProduto());
                pst.setInt(3, mod.getQuantidade());
                pst.setFloat(4, mod.getValor_uni());
                pst.setInt(5, mod.getCodigo_pro());
                pst.setBlob(6, img);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Dados Alterados Com Sucesso!!!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erro Na Alteração de Dados/n" + ex.getMessage());
            }
        }
        
        conex.desconecta();
    }
    
    public void Excluir(BeansProduto mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.getCon().prepareStatement("DELETE FROM produtos WHERE codigo_produto=?");
            pst.setInt(1, mod.getCodigo_pro());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados Excluidos Com Sucesso!!!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir dados!/nErro:" + ex.getMessage());
        }
        
        conex.desconecta();
    }
    
    public BeansProduto buscaProduto(BeansProduto mod){
        conex.conexao();
        conex.executaSQL("SELECT * FROM produtos WHERE produto LIKE '%" + mod.getPesquisa() + "%'");
        try {
            conex.rs.first();
            mod.setCodigo_pro(conex.rs.getInt("codigo_produto"));
            mod.setCodigo_barras(conex.rs.getInt("codigo_barras"));
            mod.setProduto(conex.rs.getString("produto"));
            mod.setQuantidade(conex.rs.getInt("quantidade"));
            mod.setValor_uni(conex.rs.getFloat("valor_uni"));
            mod.setImagem_pro(conex.rs.getBytes("imagem_pro"));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro Ao Buscar Produto /nErro:" + ex.getMessage());
        }
        conex.desconecta();
        return mod;
    }
    public BeansProduto retornaProduto(BeansProduto mod){
        conex.conexao();
        conex.executaSQL("SELECT * FROM produtos WHERE codigo_produto LIKE '%" + mod.getRetornar()+ "%'");
        try {
            conex.rs.first();
            mod.setCodigo_pro(conex.rs.getInt("codigo_produto"));
            mod.setCodigo_barras(conex.rs.getInt("codigo_barras"));
            mod.setProduto(conex.rs.getString("produto"));
            mod.setQuantidade(conex.rs.getInt("quantidade"));
            mod.setValor_uni(conex.rs.getFloat("valor_uni"));
            mod.setImagem_pro(conex.rs.getBytes("imagem_pro"));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro Ao Buscar Produto /nErro:" + ex.getMessage());
        }
        conex.desconecta();
        return mod;
    }
        
    public BeansProduto retornarProdutoController(int codigo_produto){
        BeansProduto modelProdutos = new BeansProduto();
        try {
            conex.conexao();
            conex.executaSQL("SELECT "
                    + "codigo_produto, "
                    + "codigo_barras,"
                    + "produto,"
                    + "valor_uni "
                    + "FROM produtos WHERE codigo_produto = '" + codigo_produto + "'");
            while (conex.rs.next()) {
                modelProdutos.setCodigo_pro(conex.rs.getInt(1));
                modelProdutos.setCodigo_barras(conex.rs.getInt(2));
                modelProdutos.setProduto(conex.rs.getString(3));
                modelProdutos.setValor_uni(conex.rs.getFloat(4));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conex.desconecta();
        }
        return modelProdutos;
    }
    
    public BeansProduto retornarProdutoControler(int codigo_produto){
        BeansProduto modelProdutos = new BeansProduto();
        try {
            conex.conexao();
            conex.executaSQL("SELECT "
                    + "codigo_produto, "
                    + "codigo_barras,"
                    + "produto,"
                    + "valor_uni,"
                    + "quantidade "
                    + "FROM produtos WHERE codigo_produto = '" + codigo_produto + "'");
            while (conex.rs.next()) {
                modelProdutos.setCodigo_pro(conex.rs.getInt(1));
                modelProdutos.setCodigo_barras(conex.rs.getInt(2));
                modelProdutos.setProduto(conex.rs.getString(3));
                modelProdutos.setValor_uni(conex.rs.getFloat(4));
                modelProdutos.setQuantidade(conex.rs.getInt(5));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conex.desconecta();
        }
        return modelProdutos;
    }

    public boolean alterarEstoqueProdutosDAO(ArrayList<BeansProduto> pListaModelProdutos) {
        try {
            conex.conexao();
            for (int i = 0; i < pListaModelProdutos.size(); i++) {
                conex.executarUpdateDeleteSQL(
                        "UPDATE produtos SET "
                        + "quantidade = '" + pListaModelProdutos.get(i).getQuantidade()+ "'"
                        + " WHERE codigo_produto = '" + pListaModelProdutos.get(i).getCodigo_pro()+ "'"
                );
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            conex.desconecta();
        }
    }
}